﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesLibro
{
    public class Comic : Libro
    {
        #region Atributos
        private int cantCuadros;
        #endregion

        #region Propiedades
        public override ETipoImpresion TipoImpresion
        {
            get
            {
                return ETipoImpresion.Color;
            }
        }
        #endregion

        #region Metodos y constructores
        public Comic(int cantCuadros, string titulo, float tamanioLetra, int ancho, int alto) :base(titulo,tamanioLetra,ancho,alto)
        {
            this.cantCuadros = cantCuadros;
        }

        public override string Mostrar()
        {
            return string.Format("Titulo: " + base.Mostrar() + "Cant. cuadros: ", this.cantCuadros.ToString() + " Tipo de impresion: " + this.TipoImpresion);
        }
        #endregion
    }
}

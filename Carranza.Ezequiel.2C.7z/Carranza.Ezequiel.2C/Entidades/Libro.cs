﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesLibro
{
    public abstract class Libro
    {
        #region Atributos
        private int altoHoja;
        private int anchoHoja;
        private List<string> Pagina;
        private float tamanioLetra;
        private string titulo;
        public enum ETipoImpresion
        {
            Color, BlancoNegro, Mixto
        }
        #endregion

        #region Propiedades
        public int AltoHoja
        {
            get
            {
                return this.altoHoja;
            }
        }

        public int AnchoHoja
        {
            get
            {
                return this.anchoHoja;
            }
        }

        public int CantidadPaginas
        {
            get
            {
                return this.altoHoja;
            }
        }

        public float TamanioLetra
        {
            get
            {
                return this.tamanioLetra;
            }
            set
            {
                if (value < (this.altoHoja + this.anchoHoja) * 0.1)
                {
                    this.tamanioLetra = value;
                }
                else this.tamanioLetra = 12;
            }
        }

        public string this[int index]
        {
            get
            {
                foreach(string p in Pagina)
                {
                    return this.Mostrar();
                }
                return "";
            }
            set
            {
                this.Pagina.Add(value);
            }
        }

        public  abstract ETipoImpresion TipoImpresion
        {
            get;
        }
        #endregion

        #region Constructores
        private Libro()
        {
            this.Pagina = new List<string>();
        }

        public Libro(string titulo, float tamanioLetra, int ancho, int alto) :this()
        {
            this.titulo = titulo;
            this.tamanioLetra = tamanioLetra;
            this.altoHoja = alto;
            this.anchoHoja = ancho;
        }
        #endregion

        #region Metodos
        public virtual string Mostrar()
        {
            return this.titulo;
        }
        #endregion

    }
}

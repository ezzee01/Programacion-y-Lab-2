﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesLibro;

namespace EntidadesBiblioteca
{
    public class Biblioteca
    {
        #region atributos
        private short cantidad;
        private List<Libro> libros;
        #endregion

        #region constructores
        static Biblioteca() 
        {
            
        }
        private Biblioteca()
        {
            this.libros = new List<Libro>();
        }

        public Biblioteca (short cantidad)
        {
            this.cantidad = cantidad;
        }
        #endregion

        #region operadores
        public static explicit operator List<Libro>(Biblioteca b)
        {
            return b.libros;
        }

        public static Biblioteca operator +(Biblioteca b , Libro l)
        {
            foreach(Libro l1 in b.libros)
            {
                if(l1 != l && l1 is null)
                {
                    b.libros.Add(l);
                }
            }
            return b;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesLibro
{
    public class Novela :Libro
    {
        #region atributos
        private int cantPaginas;

        public override ETipoImpresion TipoImpresion
        {
            get
            {
                return ETipoImpresion.BlancoNegro;
            }
        }
        #endregion


        #region constructores
        public Novela(int cantPaginas, string titulo, float tamanioLetra, int ancho, int alto):base(titulo,tamanioLetra,ancho,alto)
        {
            this.cantPaginas = cantPaginas;
        }
        #endregion

        #region metodos y operadores
        public override string Mostrar()
        {
            return string.Format("Titulo: " + base.Mostrar() + "Cant. paginas: " + this.cantPaginas + "Tipo impresion: " + this.TipoImpresion);
        }

        public static bool operator ==(Novela n1, Novela n2)
        {
            bool valor = false;
            if(n1.Mostrar().CompareTo(n2.Mostrar()) == 0)
            {
                valor = true;
            }
            return valor;
        }

        public static bool operator !=(Novela n1, Novela n2)
        {
            return !(n1 == n2);
        }
        #endregion
    }
}
